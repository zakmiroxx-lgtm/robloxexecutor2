import tkinter as tk
from tkinter import scrolledtext
import threading, subprocess, os, sys, time
import ctypes, ctypes.wintypes, struct

INJECT_STATUS = {"connected": False, "pid": None}
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
PROCESS_ALL_ACCESS     = 0x1F0FFF
MEM_COMMIT             = 0x1000
MEM_RESERVE            = 0x2000
MEM_RELEASE            = 0x8000
PAGE_EXECUTE_READWRITE = 0x40
INVALID_HANDLE         = ctypes.wintypes.HANDLE(-1).value

QUICK_SCRIPTS = {
    "Cynatica":     'loadstring(game:HttpGet("https://gist.githubusercontent.com/OfficialCynatica/636bed3e9ba0088733feb986768f8015/raw"))()',
    "Inf Yield":    'loadstring(game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"))()',
    "Dex Explorer": 'loadstring(game:HttpGet("https://raw.githubusercontent.com/infyiff/backup/main/dex.lua"))()',
    "Custom URL":   'loadstring(game:HttpGet("PASTE_URL_HERE"))()',
}

def find_pid():
    try:
        out = subprocess.check_output(
            ["tasklist","/FI","IMAGENAME eq RobloxPlayerBeta.exe","/FO","CSV","/NH"],
            stderr=subprocess.DEVNULL, text=True)
        for line in out.strip().splitlines():
            parts = line.strip('"').split('","')
            if len(parts) >= 2:
                try: return int(parts[1])
                except: continue
    except: pass
    return None

def inject_wpm(pid, script, log):
    """
    WriteProcessMemory инжект — пишем Lua скрипт в память Roblox.
    Roblox executor stub читает адрес из rbx_ptr.bin и выполняет.
    """
    try:
        h = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)
        if not h:
            log(f"[!] OpenProcess failed: {ctypes.get_last_error()}"); return False

        payload = script.encode("utf-8") + b"\x00"
        addr = kernel32.VirtualAllocEx(h, None, len(payload),
                                        MEM_COMMIT|MEM_RESERVE,
                                        PAGE_EXECUTE_READWRITE)
        if not addr:
            log(f"[!] VirtualAllocEx failed: {ctypes.get_last_error()}")
            kernel32.CloseHandle(h); return False

        written = ctypes.c_size_t(0)
        ok = kernel32.WriteProcessMemory(h, addr,
                                          ctypes.c_char_p(payload),
                                          len(payload),
                                          ctypes.byref(written))
        if not ok:
            log(f"[!] WriteProcessMemory failed: {ctypes.get_last_error()}")
            kernel32.VirtualFreeEx(h, addr, 0, MEM_RELEASE)
            kernel32.CloseHandle(h); return False

        log(f"[+] WPM: {written.value} bytes @ 0x{addr:X}")

        # Сохраняем адрес — executor stub читает его
        ptr = os.path.join(os.getenv("TEMP","C:\\Temp"), "rbx_ptr.bin")
        with open(ptr,"wb") as f: f.write(struct.pack("<Q", addr))
        log("[+] Ptr: " + ptr)

        kernel32.CloseHandle(h)
        return True
    except Exception as e:
        log(f"[!] WPM error: {e}"); return False

def send_pipe(script, log):
    h = kernel32.CreateFileW(r"\\.\pipe\RbxExec",0x40000000,0,None,3,0,None)
    if h == INVALID_HANDLE:
        log("[~] Pipe not ready"); return
    data = script.encode("utf-8")
    written = ctypes.wintypes.DWORD(0)
    kernel32.WriteFile(h, data, len(data), ctypes.byref(written), None)
    kernel32.CloseHandle(h)
    log(f"[+] Pipe: {written.value} bytes")

def write_bridge(script, log):
    p = os.path.join(os.getenv("TEMP","C:\\Temp"), "rbx_bridge.lua")
    try:
        with open(p,"w",encoding="utf-8") as f: f.write(script)
        log("[+] Bridge: " + p)
    except Exception as e: log(f"[!] {e}")

def connect(log):
    pid = find_pid()
    if not pid:
        log("[!] Roblox not found. Launch the game."); return False
    log(f"[+] Roblox PID: {pid}")
    INJECT_STATUS["pid"] = pid
    INJECT_STATUS["connected"] = True
    log("[+] Connected. Ready to execute.")
    return True

def execute(script, log):
    if not INJECT_STATUS["connected"]:
        log("[!] Connect first."); return
    pid = INJECT_STATUS["pid"]
    inject_wpm(pid, script, log)
    send_pipe(script, log)
    write_bridge(script, log)
    log("[+] Script dispatched.")

class App:
    def __init__(self, root):
        self.root = root
        root.title("XcX Executor v67")
        root.geometry("740x540")
        root.configure(bg="#0d0d0d")
        root.resizable(False, False)
        self._ui()

    def _ui(self):
        top = tk.Frame(self.root, bg="#0d0d0d")
        top.pack(fill="x", padx=16, pady=(14,0))
        tk.Label(top, text="XcX EXECUTOR", bg="#0d0d0d", fg="#c0392b",
                 font=("Consolas",20,"bold")).pack(side="left")
        self.stat = tk.Label(top, text="● DISCONNECTED", bg="#0d0d0d",
                              fg="#3d3d3d", font=("Consolas",9))
        self.stat.pack(side="right")
        tk.Label(self.root, text="v67  ·  Python ctypes inject", bg="#0d0d0d",
                 fg="#252525", font=("Consolas",8)).pack(anchor="w", padx=16)
        tk.Frame(self.root, bg="#1a1a1a", height=1).pack(fill="x", padx=16, pady=(6,8))

        qs = tk.Frame(self.root, bg="#0d0d0d")
        qs.pack(fill="x", padx=16, pady=(0,6))
        tk.Label(qs, text="Quick:", bg="#0d0d0d", fg="#444",
                 font=("Consolas",8)).pack(side="left", padx=(0,6))
        for name, code in QUICK_SCRIPTS.items():
            tk.Button(qs, text=name, bg="#141414", fg="#666",
                      activebackground="#1e1e1e", activeforeground="#aaa",
                      font=("Consolas",8), relief="flat", padx=8, pady=3,
                      cursor="hand2", bd=0,
                      command=lambda c=code: (self.editor.delete("1.0","end"),
                                              self.editor.insert("end",c+"\n"))
                      ).pack(side="left", padx=2)

        tk.Label(self.root, text="Script Editor", bg="#0d0d0d", fg="#444",
                 font=("Consolas",8)).pack(anchor="w", padx=16)
        self.editor = scrolledtext.ScrolledText(
            self.root, bg="#111", fg="#e0e0e0",
            insertbackground="#c0392b", selectbackground="#c0392b",
            font=("Consolas",11), relief="flat",
            height=12, wrap="none", padx=8, pady=8)
        self.editor.pack(fill="x", padx=16, pady=(2,8))
        self.editor.insert("end",
            'loadstring(game:HttpGet("https://gist.githubusercontent.com/'
            'OfficialCynatica/636bed3e9ba0088733feb986768f8015/raw"))()\n')

        btn = tk.Frame(self.root, bg="#0d0d0d")
        btn.pack(fill="x", padx=16, pady=(0,8))
        self.cbtn = tk.Button(btn, text="⚡  CONNECT",
            bg="#c0392b", fg="white", activebackground="#e74c3c",
            font=("Consolas",11,"bold"), relief="flat",
            padx=20, pady=7, cursor="hand2", bd=0, command=self._connect)
        self.cbtn.pack(side="left", padx=(0,8))
        self.ebtn = tk.Button(btn, text="▶  EXECUTE",
            bg="#1c1c1c", fg="#555", font=("Consolas",11),
            relief="flat", padx=20, pady=7, cursor="hand2",
            bd=0, state="disabled", command=self._execute)
        self.ebtn.pack(side="left", padx=(0,8))
        tk.Button(btn, text="✕  CLEAR", bg="#0d0d0d", fg="#333",
                  font=("Consolas",10), relief="flat", padx=12, pady=7,
                  cursor="hand2", bd=0,
                  command=lambda: self.editor.delete("1.0","end")
                  ).pack(side="left")

        tk.Label(self.root, text="Log", bg="#0d0d0d", fg="#333",
                 font=("Consolas",8)).pack(anchor="w", padx=16)
        self.log_box = scrolledtext.ScrolledText(
            self.root, bg="#080808", fg="#444", font=("Consolas",9),
            relief="flat", height=5, state="disabled", padx=6, pady=6)
        self.log_box.pack(fill="x", padx=16, pady=(2,14))

    def _log(self, msg):
        def _w():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", msg+"\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        self.root.after(0, _w)

    def _connect(self):
        self.cbtn.configure(state="disabled", text="  Connecting...")
        def _r():
            ok = connect(self._log)
            if ok:
                self.root.after(0, lambda: [
                    self.cbtn.configure(bg="#27ae60", text="✓  CONNECTED", state="normal"),
                    self.ebtn.configure(fg="#e0e0e0", state="normal"),
                    self.stat.configure(text="● CONNECTED", fg="#27ae60")])
            else:
                self.root.after(0, lambda: self.cbtn.configure(
                    bg="#c0392b", text="⚡  CONNECT", state="normal"))
        threading.Thread(target=_r, daemon=True).start()

    def _execute(self):
        s = self.editor.get("1.0","end").strip()
        if not s: self._log("[!] Empty."); return
        threading.Thread(target=execute, args=(s, self._log), daemon=True).start()

if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
