import sys, os, struct, zipfile, tempfile, subprocess, io
MARKER = b"__PAYLOAD_START__"
def run():
    exe = sys.executable if getattr(sys,"frozen",False) else os.path.abspath(__file__)
    with open(exe,"rb") as f: data = f.read()
    idx = data.find(MARKER)
    if idx == -1: sys.exit(1)
    off = idx + len(MARKER)
    sz  = struct.unpack_from("<I", data, off)[0]
    zd  = data[off+4:off+4+sz]
    out = os.path.join(tempfile.gettempdir(), "RbxExecutor")
    os.makedirs(out, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(zd)) as z: z.extractall(out)
    target = os.path.join(out, "RbxExecutor.exe")
    subprocess.Popen([target], cwd=out, close_fds=True)
if __name__ == "__main__": run()
